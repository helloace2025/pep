# Glitch Crypt: P2P Encryption

A Pen created on CodePen.

Original URL: [https://codepen.io/gbvlcwmf-the-selector/pen/pvoOZBx](https://codepen.io/gbvlcwmf-the-selector/pen/pvoOZBx).

psst~ ever wondered if that secret rant you oh-so-sneakily slipped to your bestie via text last week is safe from prying eyes? Glitch Crypt is here to keep your juicy secrets under wraps and transform your private notes into an indecipherable jumble of gibberish to anyone without your key, share that key with your trusted friend to unscramble your hot gossip! (Not designed for anything serious or business-y)